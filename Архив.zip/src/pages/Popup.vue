<template>
  <div class="container">

    <h1>popup page</h1>
    <button class="temp-btn1 hover-gradient-btn"><span data-price="$12.20"></span></button>
    <button class="temp-btn2 hover-gradient-btn old-price"><span data-price="$12.20" data-old-price="$18.90"></span></button>
    <button class="temp-btn3 hover-gradient-btn"><span data-price="$12.20"></span></button>
    <button class="temp-btn4 hover-gradient-btn"><span data-price="$12.20"></span></button>
    <button class="temp-btn5 hover-gradient-btn"><span data-price="$12.20"></span></button>
    <button class="temp-btn6 hover-gradient-btn"><span data-price="$12.20"></span></button>
    <button class="temp-btn7 hover-gradient-btn"><span data-price="$12.20"></span></button>
    <!--class="jcf-scrollable"-->
  </div>
</template>
