<template>
  <div class="alert warning">
    <div class="alert-icon"></div>
    <div class="alert-title">warning</div>
    <div class="alert-text">By clicking the "Accept" button, you confirm that you have reached the age of 18, and you
      have read and agree with the Casedrop Terms of Service:
    </div>
  </div>
</template>
