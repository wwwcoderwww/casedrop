export default {
  baseUrl: 'https://dev2.casedrop.com/api',
  url: 'https://dev2.casedrop.com',
  imgUrl: 'http://dev2.casedrop.com',
  headerImgUrl: 'https://steamcommunity-a.akamaihd.net/economy/image/',
  steamProfileUrl: 'https://steamcommunity.com/profiles/'
}
